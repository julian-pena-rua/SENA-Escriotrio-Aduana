﻿
namespace Sistema_de_registro_unico_aduanero.modelo
{
    public class Version
    {
        string titulo_programa = "Sistema de Registro Unico Aduanero";
        string versionamiento = "1.0.0";
        string creador = "Julian A. Peña";
        string fecha_creacion = "06/09/2021";

        public string Titulo_programa { get => titulo_programa; }
        public string Versionamiento { get => versionamiento; }
        public string Creador { get => creador; }
        public string Fecha_creacion { get => fecha_creacion; }
    }
}
