﻿using System.Windows.Forms;
using Sistema_de_registro_unico_aduanero.vista;
using Sistema_de_registro_unico_aduanero.modelo;
namespace Sistema_de_registro_unico_aduanero
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Version version = new Version();
            label_nombreApp.Text = "Bienvenido al " + version.Titulo_programa;
            label_copyright.Text = "";
            
        }

        private void btn_salir_Click(object sender, System.EventArgs e)
        {
            Application.Exit();
        }

        private void btn_iniciarSesion_Click(object sender, System.EventArgs e)
        {
            MenuPrincipal menuppal = new MenuPrincipal();
            menuppal.Visible = true;
            this.Visible = false;
        }
    }
}
