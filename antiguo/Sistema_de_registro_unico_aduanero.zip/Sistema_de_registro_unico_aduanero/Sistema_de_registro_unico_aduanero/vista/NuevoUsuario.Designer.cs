﻿namespace Sistema_de_registro_unico_aduanero.vista
{
    partial class NuevoUsuario
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textbox_nombre = new System.Windows.Forms.TextBox();
            this.textBox_apellido = new System.Windows.Forms.TextBox();
            this.btn_agregarEquipo = new System.Windows.Forms.Button();
            this.btn_cancelar = new System.Windows.Forms.Button();
            this.btn_agregarUsuario = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textbox_nombre
            // 
            this.textbox_nombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textbox_nombre.Location = new System.Drawing.Point(246, 33);
            this.textbox_nombre.Name = "textbox_nombre";
            this.textbox_nombre.Size = new System.Drawing.Size(327, 64);
            this.textbox_nombre.TabIndex = 3;
            this.textbox_nombre.Text = "Nombre";
            // 
            // textBox_apellido
            // 
            this.textBox_apellido.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_apellido.Location = new System.Drawing.Point(246, 122);
            this.textBox_apellido.Name = "textBox_apellido";
            this.textBox_apellido.Size = new System.Drawing.Size(327, 64);
            this.textBox_apellido.TabIndex = 4;
            this.textBox_apellido.Text = "Apellido";
            // 
            // btn_agregarEquipo
            // 
            this.btn_agregarEquipo.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_agregarEquipo.Location = new System.Drawing.Point(151, 230);
            this.btn_agregarEquipo.Name = "btn_agregarEquipo";
            this.btn_agregarEquipo.Size = new System.Drawing.Size(503, 80);
            this.btn_agregarEquipo.TabIndex = 5;
            this.btn_agregarEquipo.Text = "Agregar Equipo";
            this.btn_agregarEquipo.UseVisualStyleBackColor = true;
            // 
            // btn_cancelar
            // 
            this.btn_cancelar.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_cancelar.Location = new System.Drawing.Point(151, 428);
            this.btn_cancelar.Name = "btn_cancelar";
            this.btn_cancelar.Size = new System.Drawing.Size(503, 80);
            this.btn_cancelar.TabIndex = 6;
            this.btn_cancelar.Text = "Cancelar";
            this.btn_cancelar.UseVisualStyleBackColor = true;
            this.btn_cancelar.Click += new System.EventHandler(this.btn_cancelar_Click);
            // 
            // btn_agregarUsuario
            // 
            this.btn_agregarUsuario.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_agregarUsuario.Location = new System.Drawing.Point(151, 325);
            this.btn_agregarUsuario.Name = "btn_agregarUsuario";
            this.btn_agregarUsuario.Size = new System.Drawing.Size(503, 80);
            this.btn_agregarUsuario.TabIndex = 7;
            this.btn_agregarUsuario.Text = "Crear Usuario";
            this.btn_agregarUsuario.UseVisualStyleBackColor = true;
            // 
            // NuevoUsuario
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 520);
            this.Controls.Add(this.btn_agregarUsuario);
            this.Controls.Add(this.btn_cancelar);
            this.Controls.Add(this.btn_agregarEquipo);
            this.Controls.Add(this.textBox_apellido);
            this.Controls.Add(this.textbox_nombre);
            this.Name = "NuevoUsuario";
            this.Text = "NuevoUsuario";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textbox_nombre;
        private System.Windows.Forms.TextBox textBox_apellido;
        private System.Windows.Forms.Button btn_agregarEquipo;
        private System.Windows.Forms.Button btn_cancelar;
        private System.Windows.Forms.Button btn_agregarUsuario;
    }
}