﻿namespace Sistema_de_registro_unico_aduanero.vista
{
    partial class MenuPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_nuevo_usario = new System.Windows.Forms.Button();
            this.btn_verRegistros = new System.Windows.Forms.Button();
            this.btn_Salir = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_nuevo_usario
            // 
            this.btn_nuevo_usario.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_nuevo_usario.Location = new System.Drawing.Point(157, 33);
            this.btn_nuevo_usario.Name = "btn_nuevo_usario";
            this.btn_nuevo_usario.Size = new System.Drawing.Size(475, 76);
            this.btn_nuevo_usario.TabIndex = 0;
            this.btn_nuevo_usario.Text = "Nuevo Usuario";
            this.btn_nuevo_usario.UseVisualStyleBackColor = true;
            this.btn_nuevo_usario.Click += new System.EventHandler(this.btn_nuevo_usario_Click);
            // 
            // btn_verRegistros
            // 
            this.btn_verRegistros.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_verRegistros.Location = new System.Drawing.Point(157, 157);
            this.btn_verRegistros.Name = "btn_verRegistros";
            this.btn_verRegistros.Size = new System.Drawing.Size(475, 76);
            this.btn_verRegistros.TabIndex = 1;
            this.btn_verRegistros.Text = "Ver Registros";
            this.btn_verRegistros.UseVisualStyleBackColor = true;
            // 
            // btn_Salir
            // 
            this.btn_Salir.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Salir.Location = new System.Drawing.Point(157, 291);
            this.btn_Salir.Name = "btn_Salir";
            this.btn_Salir.Size = new System.Drawing.Size(475, 76);
            this.btn_Salir.TabIndex = 2;
            this.btn_Salir.Text = "Salir";
            this.btn_Salir.UseVisualStyleBackColor = true;
            this.btn_Salir.Click += new System.EventHandler(this.btn_Salir_Click);
            // 
            // MenuPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_Salir);
            this.Controls.Add(this.btn_verRegistros);
            this.Controls.Add(this.btn_nuevo_usario);
            this.Name = "MenuPrincipal";
            this.Text = "MenuPrincipal";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_nuevo_usario;
        private System.Windows.Forms.Button btn_verRegistros;
        private System.Windows.Forms.Button btn_Salir;
    }
}