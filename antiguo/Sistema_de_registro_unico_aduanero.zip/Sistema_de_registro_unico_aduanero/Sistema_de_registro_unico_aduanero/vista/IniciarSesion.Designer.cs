﻿namespace Sistema_de_registro_unico_aduanero
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_nombreApp = new System.Windows.Forms.Label();
            this.textbox_usuario = new System.Windows.Forms.TextBox();
            this.textBox_contrasena = new System.Windows.Forms.TextBox();
            this.btn_salir = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btn_iniciarSesion = new System.Windows.Forms.PictureBox();
            this.label_copyright = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.btn_salir)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_iniciarSesion)).BeginInit();
            this.SuspendLayout();
            // 
            // label_nombreApp
            // 
            this.label_nombreApp.AutoSize = true;
            this.label_nombreApp.BackColor = System.Drawing.Color.Transparent;
            this.label_nombreApp.Font = new System.Drawing.Font("Arial Black", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_nombreApp.ForeColor = System.Drawing.Color.White;
            this.label_nombreApp.Location = new System.Drawing.Point(56, 20);
            this.label_nombreApp.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label_nombreApp.Name = "label_nombreApp";
            this.label_nombreApp.Size = new System.Drawing.Size(146, 48);
            this.label_nombreApp.TabIndex = 1;
            this.label_nombreApp.Text = "Label1";
            // 
            // textbox_usuario
            // 
            this.textbox_usuario.BackColor = System.Drawing.SystemColors.Window;
            this.textbox_usuario.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textbox_usuario.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textbox_usuario.Location = new System.Drawing.Point(55, 59);
            this.textbox_usuario.Margin = new System.Windows.Forms.Padding(2);
            this.textbox_usuario.Name = "textbox_usuario";
            this.textbox_usuario.Size = new System.Drawing.Size(219, 38);
            this.textbox_usuario.TabIndex = 2;
            this.textbox_usuario.Text = "Usuario";
            this.textbox_usuario.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox_contrasena
            // 
            this.textBox_contrasena.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_contrasena.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox_contrasena.Location = new System.Drawing.Point(55, 108);
            this.textBox_contrasena.Margin = new System.Windows.Forms.Padding(2);
            this.textBox_contrasena.Name = "textBox_contrasena";
            this.textBox_contrasena.PasswordChar = '*';
            this.textBox_contrasena.Size = new System.Drawing.Size(219, 38);
            this.textBox_contrasena.TabIndex = 3;
            this.textBox_contrasena.Text = "Contraseña";
            this.textBox_contrasena.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btn_salir
            // 
            this.btn_salir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(242)))), ((int)(((byte)(93)))), ((int)(((byte)(39)))));
            this.btn_salir.Image = global::Sistema_de_registro_unico_aduanero.Properties.Resources.baseline_cancel_black_48dp;
            this.btn_salir.Location = new System.Drawing.Point(14, 168);
            this.btn_salir.Name = "btn_salir";
            this.btn_salir.Size = new System.Drawing.Size(96, 97);
            this.btn_salir.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btn_salir.TabIndex = 5;
            this.btn_salir.TabStop = false;
            this.btn_salir.Tag = "Salir del aplicativo.";
            this.btn_salir.Click += new System.EventHandler(this.btn_salir_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(242)))), ((int)(((byte)(93)))), ((int)(((byte)(39)))));
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.btn_salir);
            this.panel1.Controls.Add(this.btn_iniciarSesion);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.textbox_usuario);
            this.panel1.Controls.Add(this.textBox_contrasena);
            this.panel1.Location = new System.Drawing.Point(390, 130);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(293, 294);
            this.panel1.TabIndex = 6;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = global::Sistema_de_registro_unico_aduanero.Properties.Resources.baseline_lock_open_black_48dp;
            this.pictureBox2.Location = new System.Drawing.Point(14, 106);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(42, 42);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 10;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.Image = global::Sistema_de_registro_unico_aduanero.Properties.Resources.baseline_account_circle_black_48dp;
            this.pictureBox1.Location = new System.Drawing.Point(14, 56);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(42, 42);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            // 
            // btn_iniciarSesion
            // 
            this.btn_iniciarSesion.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(242)))), ((int)(((byte)(93)))), ((int)(((byte)(39)))));
            this.btn_iniciarSesion.Image = global::Sistema_de_registro_unico_aduanero.Properties.Resources.baseline_login_black_48dp;
            this.btn_iniciarSesion.Location = new System.Drawing.Point(178, 168);
            this.btn_iniciarSesion.Name = "btn_iniciarSesion";
            this.btn_iniciarSesion.Size = new System.Drawing.Size(96, 97);
            this.btn_iniciarSesion.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btn_iniciarSesion.TabIndex = 7;
            this.btn_iniciarSesion.TabStop = false;
            this.btn_iniciarSesion.Tag = "Salir del aplicativo.";
            this.btn_iniciarSesion.Click += new System.EventHandler(this.btn_iniciarSesion_Click);
            // 
            // label_copyright
            // 
            this.label_copyright.AutoSize = true;
            this.label_copyright.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(242)))), ((int)(((byte)(93)))), ((int)(((byte)(39)))));
            this.label_copyright.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_copyright.Location = new System.Drawing.Point(13, 492);
            this.label_copyright.Name = "label_copyright";
            this.label_copyright.Size = new System.Drawing.Size(64, 25);
            this.label_copyright.TabIndex = 8;
            this.label_copyright.Text = "label1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Sistema_de_registro_unico_aduanero.Properties.Resources.deposito_aduanero;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1064, 561);
            this.ControlBox = false;
            this.Controls.Add(this.label_copyright);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label_nombreApp);
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Autenticación de usuario";
            ((System.ComponentModel.ISupportInitialize)(this.btn_salir)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btn_iniciarSesion)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label_nombreApp;
        private System.Windows.Forms.TextBox textbox_usuario;
        private System.Windows.Forms.TextBox textBox_contrasena;
        private System.Windows.Forms.PictureBox btn_salir;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox btn_iniciarSesion;
        private System.Windows.Forms.Label label_copyright;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

